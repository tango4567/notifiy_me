package com.sowmitras.mukul.utils;

public class JSONData {

    String topic;
    String idCount;
    String time;
    String title;
    String id;
    String url;
    String message;


    public JSONData() {
    }

    public JSONData(String idCount, String id,String time, String topic, String title,String message, String url) {
        this.topic = topic;
        this.title = title;
        this.id = id;
        this.url = url;
        this.message = message;
        this.time = time;
        this.idCount = idCount;
    }

    public String getIdCount() {
        return idCount;
    }

    public void setIdCount(String idCount) {
        this.idCount = idCount;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
