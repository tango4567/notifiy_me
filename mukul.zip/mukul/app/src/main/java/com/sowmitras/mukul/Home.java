package com.sowmitras.mukul;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.sowmitras.mukul.adapter.DataAdapter;
import com.sowmitras.mukul.database.DBManager;
import com.sowmitras.mukul.parser.JsonParser;
import com.sowmitras.mukul.utils.JSONData;
import com.sowmitras.mukul.utils.Methods;
import com.sowmitras.mukul.utils.Strings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Home  extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, SwipeRefreshLayout.OnRefreshListener  {

    static boolean response = false;
    static boolean forGround = false;
    private static JSONData jsonData;
    private static List<JSONData> jsonDataList = new ArrayList<>();
    private static DataAdapter mAdapter;
    private static RecyclerView recyclerView;
    private LinearLayoutManager mLinearLayoutManager;

    private DrawerLayout drawer;
    private NavigationView navigationView;

    private static SwipeRefreshLayout refreshLayout;
    static EditText timer;
    static RadioGroup autoScrollSetting;
    static RadioButton autoScrollBehavior, enable, disable;
    private static TextView emptyList;
    private static String url, commonStr;

    int timeInterval;

    private static Context context;


    private static DBManager dbManager;
    private ImageButton save;



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = getApplicationContext();
        findView();

//        int id = android.os.Process.myPid();
//        Toast.makeText(context, ""+id, Toast.LENGTH_SHORT).show();
//        //TODO: Check For Stored URL if URL Found So Update @urlEditText
//        url = Methods.getUrl(this);
//        if(!url.isEmpty()){
//            //  urlEditText.setText(String.valueOf(url));
//        }





    }

    private void findView() {

        //urlEditText = findViewById(R.id.editURL);
        emptyList = findViewById(R.id.newData);

        //TODO: Setup SwipeRefreshLayout
        refreshLayout = findViewById(R.id.swipeme);
        refreshLayout.setOnRefreshListener(this);
        refreshLayout.setColorSchemeResources(
                R.color.ronbackground,
                R.color.iconbackground,
                R.color.uebackground,
                R.color.background,
                R.color.enbackground
        );


        //TODO: Setup recyclerview
        recyclerView = (RecyclerView) findViewById(R.id.list);
        mLinearLayoutManager = new LinearLayoutManager(this);
        mLinearLayoutManager.setReverseLayout(true);
        mLinearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(mLinearLayoutManager);

        jsonDataList = new ArrayList<>();
        mAdapter = new DataAdapter(jsonDataList,this);
        recyclerView.setAdapter(mAdapter);

        //TODO: Check Database is empty or not and then, Get list from database and show in recyclerView
        if(Methods.getRowCount(this)!=0){
            Methods.getListUpdate(this,jsonDataList, mAdapter, recyclerView);
        }else{
            emptyList.setVisibility(View.VISIBLE);
        }


        //TODO: Setup Navigation Drawer and Drawer Layout
        drawer = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        //TODO: Setup Database
        dbManager = new DBManager(this);
        dbManager.open();

//        urlEditText.setOnKeyListener(new View.OnKeyListener() {
//            @Override
//            public boolean onKey(View v, int keyCode, KeyEvent event) {
//                if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
//                    url = urlEditText.getText().toString().trim();
//                    if(TextUtils.isEmpty(urlEditText.getText())) {
//                        urlEditText.setError("Please Enter URL");
//                        urlEditText.requestFocus();
//                    }
//                    //TODO: Store url in shared preference
//                    Methods.storeUrl(Home.this,url);
//                    new ReceiveData().execute();
//                    urlEditText.setVisibility(View.GONE);
//                    return true;
//                }
//                return false;
//            }
//        });


    }
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        int id = menuItem.getItemId();

        switch (id) {
            case R.id.start:
                forGround = false;
//                if(Methods.getStringSharedPreference(Home.this,Strings.URL).isEmpty() && Methods.getIntDataFromSharedPreference(Home.this,Strings.SYNC_TIME)==0){
//                    if(Methods.getStringSharedPreference(Home.this,Strings.URL).isEmpty()) {
//                        showChangeLangDialog(Strings.ENTER_URL, 2).show();
//                    }
//                    if(Methods.getIntDataFromSharedPreference(Home.this,Strings.SYNC_TIME)==0){
//                        showChangeLangDialog(Strings.ENTER_TIME, 1).show();
//                    }
//                }else{
//                    Methods.storeBooleanDataInSharedPreference(Home.this, Strings.AUTO_SCROLL, true);
//                    Methods.storeBooleanDataInSharedPreference(context,Strings.RUN_IN_BACKGROUND, true);
//                    Methods.storeStringToSharedPreference(Home.this, Strings.ALWAYS_RUN_CHECK,"1");
//                    nextNotify(Integer.valueOf(timeInterval));
//                }

//
                if(check()){
                    Methods.storeBooleanDataInSharedPreference(Home.this, Strings.AUTO_SCROLL, true);
                    Methods.storeBooleanDataInSharedPreference(context,Strings.RUN_IN_BACKGROUND, true);
                    Methods.storeStringToSharedPreference(Home.this, Strings.ALWAYS_RUN_CHECK,"1");
                    nextNotify(Integer.valueOf(timeInterval));
                    Toast.makeText(context, "Notification Started", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.time_set:
                // timeInterval = Methods.getStringSharedPreference(Home.this,Strings.SYNC_TIME);

                showChangeLangDialog(Strings.ENTER_TIME, 1).show(); //TODO: Change TIMER_SET  = 1

                //Log.i("time", timeInterval);
                break;
            case R.id.changeUrl:
                //url = Methods.getStringSharedPreference(Home.this,Strings.URL);
                showChangeLangDialog(Strings.ENTER_URL, 2).show();    //TODO: Change URL  = 2
                //Log.i("url", url);
                break;
            case R.id.stopper:
                Methods.storeBooleanDataInSharedPreference(context,Strings.RUN_IN_BACKGROUND, false);
                Toast.makeText(context, "Notification Stopped", Toast.LENGTH_SHORT).show();
                disableReceiveData(context);
                break;
            case R.id.autoscroll:
                showChangeLangDialog(Strings.AUTO_SCROLLBAR, 3).show();
                break;
            default:
                break;
        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void nextNotify(int time) {
        Intent intent = new Intent(Home.this, Notifys.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 234324243, intent, 0);
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + (time * 1000), pendingIntent);
    }

    public static void next(Context context, int time) {
        Intent intent = new Intent(context, Notifys.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context.getApplicationContext(), 234324243, intent, 0);
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + (time * 1000), pendingIntent);
    }

    @Override
    public void onRefresh() {

        //TODO: Taking current value from EditText
//        url = urlEditText.getText().toString().trim();
//        if(TextUtils.isEmpty(urlEditText.getText())) {
//            urlEditText.setError("Please Enter URL");
//            urlEditText.requestFocus();
//            return;
//        }

//        //TODO: Store url in shared preference
//        Methods.storeUrl(Home.this,url);
//        new ReceiveData().execute();
//
//        //TODO: Start Sync
//        nextNotify();

//        url = Methods.getStringSharedPreference(Home.this,Strings.URL);

//        if(fieldCheck(Strings.URL,url)){
//            showChangeLangDialog(url, Strings.ENTER_URL, 2).show();
//        }else{
//            new ReceiveData(context).execute();
//            refreshLayout.setRefreshing(false);
//        }

        if(Methods.getStringSharedPreference(this,Strings.URL).isEmpty()){
            showChangeLangDialog(Strings.ENTER_URL, 2).show();
            refreshLayout.setRefreshing(false);
        }else{
            new ReceiveData(context).execute();
        }


        forGround = true;


    }

    public static class Notifys extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            //String ca = Methods.getStringSharedPreference(context, Strings.ALWAYS_RUN_CHECK);
            if(Methods.isAppIsInBackground(context)){
                //TODO: If App Running in Background
                new ReceiveData(context).execute();
                if(Methods.getBooleanDataFromSharedPreference(context,Strings.RUN_IN_BACKGROUND)){
                    next(context,  Methods.getIntDataFromSharedPreference(context,Strings.SYNC_TIME));
                }

            }else{
                new ReceiveData(context).execute();
                if(Methods.getBooleanDataFromSharedPreference(context,Strings.RUN_IN_BACKGROUND)){
                    next(context, Methods.getIntDataFromSharedPreference(context,Strings.SYNC_TIME));
                }
            }
        }

    }

    static class ReceiveData extends AsyncTask<Void, Void, Boolean> {

        Context context;
        JSONData  jsonData1;


        public ReceiveData(Context context) {
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Boolean doInBackground(Void... voids) {
            try {
                String timeStamp = new SimpleDateFormat("dd : MM : yyyy : HH : mm : ss").format(Calendar.getInstance().getTime());
                JsonParser sh = new JsonParser();
                String jsonStr = sh.makeServiceCall(Methods.getStringSharedPreference(context, Strings.URL)); //TODO: Fetch URL
                JSONObject jsonObject = new JSONObject(jsonStr);
                JSONObject data = jsonObject.getJSONObject("data");
                Log.wtf("check", jsonStr);
//                Log.wtf("check",""+
//                        String.valueOf(data.getInt("id"))+"\n"+
//                        timeStamp+"\n"+
//                        String.valueOf(data.getString("topic"))+"\n"+
//                        String.valueOf(data.getString("title"))+"\n"+
//                        String.valueOf(data.getString("message"))+"\n"+
//                        String.valueOf(data.getString("url")
//                        ));

                JSONArray links = data.getJSONArray("links");



//                JSONArray anchors = data.getJSONArray("anchors");

                Log.wtf("check",""+ links.length());
//                Log.wtf("check",""+ anchors.length());
//                Log.wtf("cheasdasdck", String.valueOf(anchors));
                Log.wtf("checasdasdk", String.valueOf(links));

                for(int i=0; i<links.length(); i++){
                  JSONObject jsonObject1 = new JSONObject(links.getString(i));

                    Log.wtf("check","Link = "+ jsonObject1.getString("link")+"\n"+"Title = "+ jsonObject1.getString("title"));
                }
//                for(int i=0; i<anchors.length(); i++){
//                    Log.wtf("check",""+ anchors.getString(i));
//
//                }
//




//                jsonData = new JSONData("",
//                        String.valueOf(data.getInt("id")),
//                        timeStamp,
//                        String.valueOf(data.getString("topic")),
//                        String.valueOf(data.getString("title")),
//                        String.valueOf(data.getString("message")),
//                        String.valueOf(links.length()),
//                        String.valueOf(anchors.length()),
//                        String.valueOf(links),
//                        String.valueOf(anchors),
//                        String.valueOf(data.getString("url")));
                response = true;

            }catch (Exception e) {
                e.printStackTrace();

            }
            return response;
        }

        @Override
        protected void onPostExecute(Boolean aVoid) {
            super.onPostExecute(aVoid);
            if(Methods.isAppIsInBackground(context)){
                DBManager db =  new DBManager(context);
                db.open();
                jsonData1 = jsonData;
                //db.insert(jsonData1); //TODO: Don't forget to remove this //
                db.close();
                //Log.i("Running","Check");
                NotificationManager mNotifyManager = Methods.createNotificationChannel(context);
                Methods.sendNotification(context,mNotifyManager, jsonData1.getTopic(),jsonData1.getTitle());
                Methods.deleteCache(context);
            }else{
                if(aVoid){
                    // jsonDataList.add(jsonData);
                   // dbManager.insert(jsonData);  //TODO: Don't forget to remove this //
//                    dbManager.close();
                    //  mAdapter.notifyDataSetChanged();
                    Methods.getListUpdate(context,jsonDataList,mAdapter,recyclerView);

                    if(forGround){
                        recyclerView.smoothScrollToPosition(mAdapter.getItemCount());
                    }

                    if(Methods.getBooleanDataFromSharedPreference(context,Strings.AUTO_SCROLL)){
                        recyclerView.smoothScrollToPosition(mAdapter.getItemCount());
                    }

                    // Methods.getListUpdate(context,jsonDataList, mAdapter, recyclerView);
                    if(refreshLayout.isRefreshing()){
                        refreshLayout.setRefreshing(false);
                    }else{
                        //  next(context);
                    }
                    emptyList.setVisibility(View.GONE);
                }
            }


        }
    }

    public AlertDialog showChangeLangDialog(String title, final int type) {
        final AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.common, null);
        dialogBuilder.setView(dialogView);
        dialogBuilder.setTitle(title);

        // Toast.makeText(context, data, Toast.LENGTH_SHORT).show();

        autoScrollSetting =  dialogView.findViewById(R.id.autoScrollSetting);
        enable = dialogView.findViewById(R.id.enable);
        disable = dialogView.findViewById(R.id.disable);
        timer =  dialogView.findViewById(R.id.npTimer);
        save = dialogView.findViewById(R.id.save);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            dialogBuilder.setIcon(getDrawable(R.mipmap.ic_launcher));
        }

        switch (type){
            case 1:
                int i = Methods.getIntDataFromSharedPreference(Home.this,Strings.SYNC_TIME);
                timer.setText(String.valueOf(i));
                timer.setInputType(InputType.TYPE_CLASS_NUMBER);
                autoScrollSetting.setVisibility(View.GONE);
                break;
            case 2:
                //timer.setInputType(InputType.TYPE_TEXT_VARIATION_NORMAL);
                if(Methods.getStringSharedPreference(context,Strings.URL).isEmpty()){
                    timer.setHint("http:// or https:// is required");
                }
                timer.setText(Methods.getStringSharedPreference(context,Strings.URL));
                //  Toast.makeText(context, Methods.getStringSharedPreference(context,Strings.URL), Toast.LENGTH_SHORT).show();
                autoScrollSetting.setVisibility(View.GONE);
                break;
            case 3:
                timer.setVisibility(View.GONE);
                save.setVisibility(View.GONE);
                autoScrollSetting.setVisibility(View.VISIBLE);
                boolean b = Methods.getBooleanDataFromSharedPreference(Home.this,Strings.AUTO_SCROLL);
                if(b){
                    enable.setChecked(true);
                    disable.setChecked(false);
                }else{
                    enable.setChecked(false);
                    disable.setChecked(true);
                }
                dialogBuilder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(enable.isChecked()){
                            Methods.storeBooleanDataInSharedPreference(Home.this, Strings.AUTO_SCROLL, true);
                        }
                        if(disable.isChecked()){
                            Methods.storeBooleanDataInSharedPreference(Home.this, Strings.AUTO_SCROLL, false);
                        }
                    }
                });
                break;
        }


        dialogBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                if(refreshLayout.isRefreshing()) {
                    refreshLayout.setRefreshing(false);
                }
                timer.setText("");
            }
        });
        final AlertDialog b = dialogBuilder.create();
        b.setCancelable(false);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                commonStr = timer.getText().toString().trim();
                switch (type){
                    case 1:
                        if(TextUtils.isEmpty(timer.getText())) {
                            timer.setError("Please Enter Time");
                        }else {
                            Methods.storeIntDataInSharedPreference(Home.this, Strings.SYNC_TIME, Integer.valueOf(commonStr));
                            timer.setText("");
                            b.dismiss();
                        }
                        break;
                    case 2:
                        if(TextUtils.isEmpty(timer.getText())) {
                            timer.setError("Please Enter URL");
                        }else {
                            Methods.storeStringToSharedPreference(Home.this, Strings.URL, commonStr);
                            b.dismiss();
                        }
                        break;
                    default:
                        Toast.makeText(Home.this, "s", Toast.LENGTH_SHORT).show();
                        break;
                }



//                if(TextUtils.isEmpty(timer.getText())) {
//                    if(type==1){
//                        timer.setError("Please Enter Time");
//                    }else{
//                        timer.setError("Please Enter URL");
//                    }
//                    timer.requestFocus();
//                    return;
//                }
//                if(type==1){
//                    Methods.storeStringToSharedPreference(Home.this, Strings.SYNC_TIME, commonStr.toLowerCase());
//                }else{
//                    Methods.storeStringToSharedPreference(Home.this, Strings.URL, commonStr.toLowerCase());
//                }
//                Methods.hideSoftKeyboard(Home.this);
//                b.dismiss();
//                //new ReceiveData().execute();
//                if(refreshLayout.isRefreshing()) {
//                    refreshLayout.setRefreshing(false);
//                }

            }
        });



        return b;
    }

//    private boolean fieldCheck(String key, String value){
//        boolean b = false;
//        value = Methods.getStringSharedPreference(Home.this,key);
//        if(value.equals(null) || value.isEmpty()){
////            showChangeLangDialog(Strings.ENTER_URL, 2).show();
//            b = true;
//        }
//        return b;
//    }

    @Override
    protected void onResume() {
        super.onResume();
        if(Methods.getRowCount(this)!=0){
            Methods.getListUpdate(this,jsonDataList, mAdapter, recyclerView);
        }else{
            emptyList.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    public void killMe() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {

        ActivityManager am = (ActivityManager)
                context.getSystemService(Context.ACTIVITY_SERVICE);
        Method forceStopPackage = null;

        forceStopPackage = am.getClass().getDeclaredMethod("forceStopPackage", String.class);

        forceStopPackage.setAccessible(true);
        forceStopPackage.invoke(am, "com.sowmitras.mukul");
    }

    public void KillApplication(String KillPackage){
        ActivityManager am = (ActivityManager)this.getSystemService(Context.ACTIVITY_SERVICE);

        Intent startMain = new Intent(Intent.ACTION_MAIN);
        startMain.addCategory(Intent.CATEGORY_HOME);
        startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        this.startActivity(startMain);

       // am.killBackgroundProcesses(KillPackage);
        //Toast.makeText(getBaseContext(),"Process Killed : " + KillPackage  ,Toast.LENGTH_LONG).show();
    }

    public void disableReceiveData(Context context){
        ComponentName receiver = new ComponentName(context, Notifys.class);
        PackageManager pm = this.getPackageManager();
        pm.setComponentEnabledSetting(receiver,PackageManager.COMPONENT_ENABLED_STATE_DEFAULT,PackageManager.DONT_KILL_APP);
        //Toast.makeText(this, "Disabled broadcst receiver", Toast.LENGTH_SHORT).show();
    }

    public boolean check(){
        boolean v = false;
        if(Methods.getStringSharedPreference(Home.this,Strings.URL).isEmpty()){
            showChangeLangDialog(Strings.ENTER_URL, 2).show();
            Toast.makeText(context, "If Lock Button won't work then press \n Cancel", Toast.LENGTH_LONG).show();
            }else{
            v = true;
        }
        if(Methods.getIntDataFromSharedPreference(Home.this,Strings.SYNC_TIME)==0){
            showChangeLangDialog(Strings.ENTER_TIME, 1).show();

            Toast.makeText(context, "If Lock Button won't work then press \n Cancel", Toast.LENGTH_LONG).show();
            v = false;
        }else{
            v = true;
        }
        return v;
    }
}
