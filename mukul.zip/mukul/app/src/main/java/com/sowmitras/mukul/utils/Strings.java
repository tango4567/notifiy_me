package com.sowmitras.mukul.utils;

public class Strings {
    public static final String HTTP_URL = "http://dsfsdfsfef.getenjoyment.net/beacon.php";
    public static final String HTTP_URL2 = "https://api.myjson.com/bins/1fksey";
    public static final String FAILED = "FaILEd oT lOAd dAtA";
    public static final String ID = "id";
    public static final String TOPIC = "topic";
    public static final String TITLE = "title";
    public static final String MESSAGE = "message";
    public static final String URL = "url";
    public static final String SYNC_TIME = "time";
    public static final String DATA = "data";
    public static final String NOTIFY_TOPIC = "mukul";
    public static final String SHARED_PREFERENCE = "mukul_pre";
    // Constants for the notification actions buttons.
    public static final String ACTION_UPDATE_NOTIFICATION =
            "com.sowmitras.mukul.ACTION_UPDATE_NOTIFICATION";
    // Notification channel ID.
    public static final String PRIMARY_CHANNEL_ID =
            "primary_notification_channel";
    // Notification ID.
    public static final int NOTIFICATION_ID = 0;

    public static final String ENTER_TIME = "Enter Time";
    public static final String ENTER_URL = "Enter URL";

    public static final String ALWAYS_RUN_CHECK = "always";
    public static final String AUTO_SCROLLBAR = "Auto Scrollbar Setting";
    public static final String AUTO_SCROLL = "scroll";
    public static final String RUN_IN_BACKGROUND = "long_time_run";




}
