package com.sowmitras.mukul.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.sowmitras.mukul.utils.JSONData;

public class DBManager {

    private DatabaseHelper dbHelper;

    private Context context;

    private SQLiteDatabase database;

    public DBManager(Context c) {
        context = c;
    }

    public DBManager open() throws SQLException {
        dbHelper = new DatabaseHelper(context);
        database = dbHelper.getWritableDatabase();

        return this;
    }

    public void close() {
        dbHelper.close();
    }

    public void insert(JSONData data) {
        ContentValues contentValue = new ContentValues();
        contentValue.put(DatabaseHelper.ID, data.getId());
        contentValue.put(DatabaseHelper.TIME, data.getTime());
        contentValue.put(DatabaseHelper.TOPIC, data.getTopic());
        contentValue.put(DatabaseHelper.TITLE, data.getTitle());
        contentValue.put(DatabaseHelper.MESSAGE, data.getMessage());
        contentValue.put(DatabaseHelper.LINK_COUNT, data.getLink_counts());
        contentValue.put(DatabaseHelper.ANCHOR_COUNT, data.getAnchor_counts());
        contentValue.put(DatabaseHelper.LINKS, data.getLinks());
        contentValue.put(DatabaseHelper.ANCHORS, data.getAnchors());
        contentValue.put(DatabaseHelper.URL, data.getUrl());

        database.insert(DatabaseHelper.TABLE_NAME, null, contentValue);

       // Log.i("insert", "Login");
    }

    public Cursor fetch() {
        String[] columns = new String[] {
                DatabaseHelper.MAIN_ID,
                DatabaseHelper.ID,
                DatabaseHelper.TIME,
                DatabaseHelper.TOPIC,
                DatabaseHelper.TITLE,
                DatabaseHelper.MESSAGE,
                DatabaseHelper.LINK_COUNT,
                DatabaseHelper.ANCHOR_COUNT,
                DatabaseHelper.LINKS,
                DatabaseHelper.ANCHORS,
                DatabaseHelper.URL };
        Cursor cursor = database.query(DatabaseHelper.TABLE_NAME, columns, null, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
        }
        return cursor;
    }

}

