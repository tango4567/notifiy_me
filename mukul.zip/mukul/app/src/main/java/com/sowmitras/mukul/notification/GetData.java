package com.sowmitras.mukul.notification;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.TextView;

import com.sowmitras.mukul.adapter.DataAdapter;
import com.sowmitras.mukul.database.DBManager;
import com.sowmitras.mukul.parser.JsonParser;
import com.sowmitras.mukul.utils.JSONData;
import com.sowmitras.mukul.utils.Strings;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

public class GetData extends AsyncTask<Void, Void, Void> {

    Context context;
    String getURL;
    List<JSONData> movieList;
    DataAdapter mAdapter;
    String id, topic, title, message, url, bag;
    JSONData movie;
    DBManager dbManager;

    RecyclerView recyclerView;
    SwipeRefreshLayout refreshLayout;
    LinearLayoutManager linearLayoutManager;

//    public GetData(Context context, String parsingUrl, List<JSONData> movieList, DataAdapter mAdapter,String bag,
//                   LinearLayoutManager linearLayoutManager, RecyclerView recyclerView, SwipeRefreshLayout refreshLayout) {
//        this.context = context;
//        this.getURL = parsingUrl;
//        this.movieList = movieList;
//        this.mAdapter = mAdapter;
//
//        this.bag = bag;
//        this.linearLayoutManager = linearLayoutManager;
//        this.recyclerView = recyclerView;
//        this.refreshLayout = refreshLayout;
//        dbManager = new DBManager(context);
//        dbManager.open();
//
//    }

    public GetData(Context context, String parsingUrl, List<JSONData> movieList, DataAdapter mAdapter, String bag) {
        this.context = context;
        this.getURL = parsingUrl;
        this.movieList = movieList;
        this.mAdapter = mAdapter;
        this.bag = bag;

        dbManager = new DBManager(context);
        dbManager.open();

    }


//    public GetData(Context context, String parsingUrl, List<JSONData> movieList, String bag) {
//        this.context = context;
//        this.getURL = parsingUrl;
//        this.movieList = movieList;
//        this.bag = bag;
//        dbManager = new DBManager(context);
//        dbManager.open();
//
//    }


    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected Void doInBackground(Void... voids) {

        try {
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
            JsonParser sh = new JsonParser();
            String jsonStr = sh.makeServiceCall(getURL);
            JSONObject jsonObject = new JSONObject(jsonStr);
            JSONObject data = jsonObject.getJSONObject("data");
           // movie = new JSONData(String.valueOf(data.getInt("id")),timeStamp,String.valueOf(data.getString("topic")), String.valueOf(data.getString("title")), String.valueOf(data.getString("message")),String.valueOf(data.getString("url")));

        } catch (Exception ex) {
            ex.printStackTrace();
           // movie = new JSONData(Strings.FAILED,Strings.FAILED,Strings.FAILED,Strings.FAILED,Strings.FAILED,Strings.FAILED);

        }



        return null;
    }


    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        if(!movie.getId().equals(Strings.FAILED)){
            movieList.add(movie);

            dbManager.insert(movie);

            mAdapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
                @Override
                public void onItemRangeInserted(int positionStart, int itemCount) {
                    super.onItemRangeInserted(positionStart, itemCount);

                    int friendlyMessageCount = mAdapter.getItemCount();
                    int lastVisiblePosition = linearLayoutManager.findLastCompletelyVisibleItemPosition();
                    // If the recycler view is initially being loaded or the user is at the bottom of the list, scroll
                    // to the bottom of the list to show the newly added message.
                    if (lastVisiblePosition == -1 ||
                            (positionStart >= (friendlyMessageCount - 1) && lastVisiblePosition == (positionStart - 1))) {
                        recyclerView.scrollToPosition(positionStart);
                    }
                }

            }); mAdapter.notifyDataSetChanged();


            refreshLayout.setRefreshing(false);

        }
    }

}
