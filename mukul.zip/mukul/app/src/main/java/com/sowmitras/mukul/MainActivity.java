package com.sowmitras.mukul;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.sowmitras.mukul.adapter.DataAdapter;
import com.sowmitras.mukul.utils.JSONData;
import com.sowmitras.mukul.utils.Methods;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, SwipeRefreshLayout.OnRefreshListener {

//    private FirebaseAuth mFirebaseAuth;
//    private FirebaseUser mFirebaseUser;


    private SharedPreferences sharedpreferences;
    private SharedPreferences.Editor editor;
    private boolean alert;


    public String parsingUrl;
    public EditText parsingUrlEdt;
    private TextView nodataTxt;
    private ImageButton saveImgBtn;
    private DrawerLayout drawer;
    private Toolbar toolbar;
    private FloatingActionButton fab;
    private ActionBarDrawerToggle toggle;
    private NavigationView navigationView;

    private List<JSONData> movieList = new ArrayList<>();
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager recyclerLayoutManager;
    private LinearLayoutManager mLinearLayoutManager;


    private SwipeRefreshLayout refreshLayout;
    private DataAdapter mAdapter;
    private boolean isFragmentDisplayed = false;
    static final String STATE_FRAGMENT = "state_of_fragment";



    private static final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        fab = (FloatingActionButton) findViewById(R.id.fab);
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        parsingUrlEdt = (EditText) findViewById(R.id.editURL);
        nodataTxt = (TextView) findViewById(R.id.newData);
        saveImgBtn = (ImageButton) findViewById(R.id.saveImgBtn);

        recyclerView = (RecyclerView) findViewById(R.id.list);

       // mAdapter = new DataAdapter(movieList);


        refreshLayout = findViewById(R.id.swipeme);
        refreshLayout.setOnRefreshListener(this);
        refreshLayout.setColorSchemeResources(
                R.color.ronbackground,
                R.color.iconbackground,
                R.color.uebackground,
                R.color.background,
                R.color.enbackground
        );



        final RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        ((LinearLayoutManager) mLayoutManager).setReverseLayout(true);
        ((LinearLayoutManager) mLayoutManager).setStackFromEnd(true);

        mLinearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(mLinearLayoutManager);
        recyclerView.setLayoutManager(mLayoutManager);

        recyclerView.setItemAnimator(new DefaultItemAnimator());



        mAdapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onItemRangeInserted(int positionStart, int itemCount) {
                super.onItemRangeInserted(positionStart, itemCount);

                int friendlyMessageCount = mAdapter.getItemCount();
                int lastVisiblePosition =  ((LinearLayoutManager) mLayoutManager).findLastCompletelyVisibleItemPosition();
                // If the recycler view is initially being loaded or the user is at the bottom of the list, scroll
                // to the bottom of the list to show the newly added message.
                if (lastVisiblePosition == -1 ||
                        (positionStart >= (friendlyMessageCount - 1) && lastVisiblePosition == (positionStart - 1))) {
                    recyclerView.scrollToPosition(positionStart);
                }
            }

        });




        recyclerView.setAdapter(mAdapter);


        setSupportActionBar(toolbar);



        if (savedInstanceState != null) {
            isFragmentDisplayed = savedInstanceState.getBoolean(STATE_FRAGMENT);
            if (isFragmentDisplayed) {
                fab.setBackgroundResource(android.R.drawable.ic_menu_close_clear_cancel);
            }
        }
        parsingUrl = Methods.getUrl(this);
        if(!parsingUrl.isEmpty()){
            parsingUrlEdt.setText(String.valueOf(parsingUrl));
        }



        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                parsingUrl = parsingUrlEdt.getText().toString().trim();
                if(TextUtils.isEmpty(parsingUrlEdt.getText())) {
                    parsingUrlEdt.setError("Please Enter URL");
                    parsingUrlEdt.requestFocus();
                    return;
                }
                Methods.storeUrl(MainActivity.this,parsingUrl);
                //new GetData(MainActivity.this, parsingUrl.toLowerCase(),movieList, mAdapter, nodataTxt, "for",mLinearLayoutManager,recyclerView, refreshLayout).execute();

            }
        });


        toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();


        navigationView.setNavigationItemSelectedListener(this);

        if((mLinearLayoutManager).findFirstVisibleItemPosition()==0){
           // Log.i("========","if");
        }else{
           // Log.i("========","else");
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            recyclerView.setOnScrollChangeListener(new View.OnScrollChangeListener() {
                @Override
                public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                   // Log.i("Scroll Position", String.valueOf("\nScroll_X:= "+scrollX+"\n"+"Scroll_Y:= "+scrollY+"\n"+"Old Scroll_X:= "+oldScrollX+"\n"+"Old Scroll_Y:= "+oldScrollY));
                }
            });
        }


    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        switch (id) {
            case R.id.start:
              //  Methods.nextNotify(MainActivity.this,5, true);


                if(!Methods.isAppIsInBackground(MainActivity.this)){

                }else{

                }
                break;
            case R.id.stopper:
//                Methods.stopNotify(MainActivity.this, false);
                break;
            default:
                break;
        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @SuppressLint("RestrictedApi")
    public void displayFragment() {
        // Instantiate the fragment.

        isFragmentDisplayed = true;

    }

    /**
     * This method is called when the user clicks the button to
     * close the fragment.
     */
    public void closeFragment() {

        isFragmentDisplayed = false;
    }


    @Override
    public void onStart() {
        super.onStart();
//        FirebaseApp.initializeApp(this);
//
//        mFirebaseAuth = FirebaseAuth.getInstance();
//        mFirebaseUser = mFirebaseAuth.getCurrentUser();

//        if(mFirebaseUser!=null){


            Methods.getListUpdate(this,movieList,mAdapter, recyclerView);


            if(mAdapter.getItemCount()==0){
                nodataTxt.setVisibility(View.VISIBLE);
//            }


        }else{
//            mFirebaseAuth.signInAnonymously()
//                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
//                        @Override
//                        public void onComplete(@NonNull Task<AuthResult> task) {
//                            if (task.isSuccessful()) {
//                                // Sign in success, update UI with the signed-in user's information
//                                //Log.d(TAG, "signInAnonymously:success");
//                                mFirebaseUser = mFirebaseAuth.getCurrentUser();
//                                // Toast.makeText(MainActivity.this, "signInAnonymously:success", Toast.LENGTH_SHORT).show();
//
//                                Methods.storeUrl(MainActivity.this, Strings.HTTP_URL);
//                            } else {
//                                // If sign in fails, display a message to the user.
//                                //Log.w(TAG, "signInAnonymously:failure", task.getException());
//                                ////Toast.makeText(MainActivity.this, "Authentication failed.",Toast.LENGTH_SHORT).show();
//
//                            }
//
//
//                        }
//                    });
        }
    }




    public  void update(){
       // Methods.storeUrl(MainActivity.this,parsingUrl);
       // new GetData(MainActivity.this, parsingUrl.toLowerCase(),movieList, mAdapter, nodataTxt, "for").execute();
    }


    @Override
    public void onRefresh() {
        Methods.storeUrl(MainActivity.this,parsingUrl);
        //new GetData(MainActivity.this, parsingUrl.toLowerCase(),movieList, mAdapter, nodataTxt, "for",mLinearLayoutManager,recyclerView, refreshLayout).execute();
    }
}
