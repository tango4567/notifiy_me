package com.sowmitras.mukul.notification;

import android.app.NotificationManager;
import android.content.Context;
import android.os.AsyncTask;
import android.os.StrictMode;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.sowmitras.mukul.adapter.DataAdapter;
import com.sowmitras.mukul.database.DBManager;
import com.sowmitras.mukul.parser.JsonParser;
import com.sowmitras.mukul.utils.JSONData;
import com.sowmitras.mukul.utils.Methods;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ReceiveData extends AsyncTask<Void, Void, Boolean> {

    boolean response = false;
    int operationType;
    private String url;
    private Context context;
    private JSONData jsonData ;
    private DataAdapter mAdapter;
    private DBManager dbManager;
    private RecyclerView recyclerView;
    private List<JSONData> jsonDataList;
    private SwipeRefreshLayout refreshLayout;
    private LinearLayoutManager layoutManager;
    private NotificationManager mNotifyManager;

//    private List<JSONData> jsonData;

    public ReceiveData(int operationType, String url,
                       SwipeRefreshLayout refreshLayout,
                       DataAdapter mAdapter,List<JSONData> jsonDataList,
                       LinearLayoutManager layoutManager,
                       RecyclerView recyclerView,
                       Context context) {
        this.operationType = operationType;
        this.url = url;
        this.operationType = operationType;
        this.refreshLayout = refreshLayout;
        this.mAdapter = mAdapter;
        this.jsonDataList = jsonDataList;
        this.layoutManager = layoutManager;
        this.recyclerView = recyclerView;
        this.context = context;
        dbManager = new DBManager(context);
        dbManager.open();
    }


    public ReceiveData(Context context, int operationType, String url){
        this.operationType = operationType;
        this.url = url;
        dbManager = new DBManager(context);
        dbManager.open();
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(Boolean aBoolean) {
        super.onPostExecute(aBoolean);
        Log.i("check", String.valueOf(aBoolean));
//        Log.i("check", String.valueOf(jsonData.getTopic()));
        if(aBoolean){
            switch (operationType) {
                case 1:
                    jsonDataList.add(jsonData);
                    mAdapter.notifyDataSetChanged();
                    refreshLayout.setRefreshing(false);
                    recyclerView.smoothScrollToPosition(mAdapter.getItemCount());
                    dbManager.insert(jsonData);
                    mNotifyManager = Methods.createNotificationChannel(context);
                    Methods.sendNotification(context,mNotifyManager, jsonData.getTopic(),jsonData.getTitle());
                    break;
                case 2:
                    dbManager.insert(jsonData);

                    break;
                default:
                    break;
            }

        }

    }

    @Override
    protected Boolean doInBackground(Void... voids) {
//        if (android.os.Build.VERSION.SDK_INT > 9){
//            StrictMode.ThreadPolicy policy = new
//                    StrictMode.ThreadPolicy.Builder().permitAll().build();
//            StrictMode.setThreadPolicy(policy);
//        }
        try {
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
            JsonParser sh = new JsonParser();
            String jsonStr = sh.makeServiceCall(url); //TODO: Fetch URL
            JSONObject jsonObject = new JSONObject(jsonStr);
            JSONObject data = jsonObject.getJSONObject("data");

            switch (operationType){
                case 1:  //TODO: App Is running in forground
                   // jsonData = new JSONData(String.valueOf(data.getInt("id")),timeStamp,String.valueOf(data.getString("topic")), String.valueOf(data.getString("title")), String.valueOf(data.getString("message")),String.valueOf(data.getString("url")));
                    response = true;
                    break;
                case 2:
                   // jsonData = new JSONData(String.valueOf(data.getInt("id")),timeStamp,String.valueOf(data.getString("topic")), String.valueOf(data.getString("title")), String.valueOf(data.getString("message")),String.valueOf(data.getString("url")));
                    response = true;
                    break;
                default:


                    break;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            response = false;
        }
        return response;
    }


}
