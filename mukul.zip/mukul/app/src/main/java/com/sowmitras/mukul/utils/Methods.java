package com.sowmitras.mukul.utils;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.Spanned;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.sowmitras.mukul.Home;
import com.sowmitras.mukul.R;
import com.sowmitras.mukul.adapter.DataAdapter;
import com.sowmitras.mukul.database.DBManager;

import java.io.File;
import java.util.List;
import java.util.Random;


public class Methods {

    public static void stopNotify(Context context){
        //storeData(context, b);
        AlarmManager alarmManager = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, Home.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);

//        PendingIntent pintent = PendingIntent.getActivity(context, 0, intent, 0);
        PendingIntent pintent  = PendingIntent.getBroadcast(context,234324243, intent,PendingIntent.FLAG_UPDATE_CURRENT);


        try {
            alarmManager.cancel(pintent);
          //  Log.e("TAG", "Cancelling all pending intents");
        } catch (Exception e) {
           // Log.e("TAG", "AlarmManager update was not canceled. " + e.toString());
        }
    }

    public static Spanned spannedText(String s) {
        Spanned string = null;
        if (s == null && s == "") {
            string = Html.fromHtml("");
        } else {
            string = Html.fromHtml(s);
        }
        return string;
    }

    public static boolean getBooleanDataFromSharedPreference(Context context, String key){
        boolean b;
        SharedPreferences sharedPreferences = context.getSharedPreferences(Strings.SHARED_PREFERENCE, Context.MODE_PRIVATE);
        b = sharedPreferences.getBoolean(key,false);
        return b;
    }

    public static void storeBooleanDataInSharedPreference(Context context, String key, boolean value){
        SharedPreferences sharedPreferences = context.getSharedPreferences(Strings.SHARED_PREFERENCE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(key, value);
        editor.commit();
    }

    public static int getIntDataFromSharedPreference(Context context, String key){
        int b;
        SharedPreferences sharedPreferences = context.getSharedPreferences(Strings.SHARED_PREFERENCE, Context.MODE_PRIVATE);
        try{
            b = sharedPreferences.getInt(key, 0);
            if(b == 0){
                b = 0;
            }
        }catch (Exception e){
            b = 0;
        }
        return b;
    }

    public static void storeIntDataInSharedPreference(Context context, String key, int value){
        SharedPreferences sharedPreferences = context.getSharedPreferences(Strings.SHARED_PREFERENCE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(key, value);
        editor.commit();
    }

    public static String getUrl(Context context){
        SharedPreferences sharedPreferences = context.getSharedPreferences(Strings.SHARED_PREFERENCE, Context.MODE_PRIVATE);
        String parsingUrl = sharedPreferences.getString("url", "");
        return parsingUrl;
    }

    public static void storeUrl(Context context, String url){
        SharedPreferences sharedPreferences = context.getSharedPreferences(Strings.SHARED_PREFERENCE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("url", url);
        editor.commit();
    }

    /**
     * Method checks if the app is in background or not
     */
    public static boolean isAppIsInBackground(Context context) {
        boolean isInBackground = true;
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT_WATCH) {
            List<ActivityManager.RunningAppProcessInfo> runningProcesses = am.getRunningAppProcesses();
            for (ActivityManager.RunningAppProcessInfo processInfo : runningProcesses) {
                if (processInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                    for (String activeProcess : processInfo.pkgList) {
                        if (activeProcess.equals(context.getPackageName())) {
                            isInBackground = false;
                        }
                    }
                }
            }
        } else {
            List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);
            ComponentName componentInfo = taskInfo.get(0).topActivity;
            if (componentInfo.getPackageName().equals(context.getPackageName())) {
                isInBackground = false;
            }
        }

        return isInBackground;
    }

    public static void getListUpdate(Context context, List<JSONData> movieList, DataAdapter mAdapter, RecyclerView recyclerView) {
        movieList.clear();
        DBManager dbManager = new DBManager(context);
        dbManager.open();
        Cursor cursor = dbManager.fetch();
       // Log.i("check", String.valueOf( cursor.getCount()));
        if (cursor.getCount() != 0) {
            while (!cursor.isAfterLast()) {
                JSONData movie = new JSONData(
                        String.valueOf(cursor.getString(0)),
                        String.valueOf(cursor.getString(1)),
                        String.valueOf(cursor.getString(2)),
                        String.valueOf(cursor.getString(3)),
                        String.valueOf(cursor.getString(4)),
                        String.valueOf(cursor.getString(5)),
                        String.valueOf(cursor.getString(6)),
                        String.valueOf(cursor.getString(7)),
                        String.valueOf(cursor.getString(8)),
                        String.valueOf(cursor.getString(9)),
                        String.valueOf(cursor.getString(10)));
                movieList.add(movie);
                mAdapter.notifyDataSetChanged();
                cursor.moveToNext();
                if(Methods.getBooleanDataFromSharedPreference(context,Strings.AUTO_SCROLL)){
                    recyclerView.smoothScrollToPosition(mAdapter.getItemCount());
                }
            }
        }
    }

    public static int getRowCount(Context context){
        DBManager dbManager = new DBManager(context);
        dbManager.open();
        Cursor cursor = dbManager.fetch();
        return  cursor.getCount();
    }

    /**
     * Creates a Notification channel, for OREO and higher.
     */
    public static NotificationManager createNotificationChannel(Context context) {
        NotificationManager mNotifyManager;
        // Create a notification manager object.
        mNotifyManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        // Notification channels are only available in OREO and higher.
        // So, add a check on SDK version.
        if (android.os.Build.VERSION.SDK_INT >=
                android.os.Build.VERSION_CODES.O) {

            // Create the NotificationChannel with all the parameters.
            NotificationChannel notificationChannel = new NotificationChannel(Strings.PRIMARY_CHANNEL_ID,context.getString(R.string.notification_channel_name), NotificationManager.IMPORTANCE_HIGH);

            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(Color.RED);
            notificationChannel.enableVibration(true);
            notificationChannel.setDescription(context.getString(R.string.notification_channel_description));

            mNotifyManager.createNotificationChannel(notificationChannel);
        }
        return mNotifyManager;
    }

    /**
     * Helper method that builds the notification.
     *
     * @return NotificationCompat.Builder: notification build with all the
     * parameters.
     */
    public static NotificationCompat.Builder getNotificationBuilder(Context context ,String topic, String title) {

        // Set up the pending intent that is delivered when the notification
        // is clicked.
        Intent notificationIntent = new Intent(context, Home.class);
        PendingIntent notificationPendingIntent = PendingIntent.getActivity
                (context, Strings.NOTIFICATION_ID, notificationIntent,PendingIntent.FLAG_UPDATE_CURRENT);

        // Build the notification with all of the parameters.
        NotificationCompat.Builder notifyBuilder = new NotificationCompat
                .Builder(context, Strings.PRIMARY_CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(topic)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setAutoCancel(true).setContentIntent(notificationPendingIntent)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setVibrate(new long[]{0L})/*
                .setDefaults(NotificationCompat.DEFAULT_ALL)*/;
        return notifyBuilder;
    }

    /**
     * OnClick method for the "Notify Me!" button.
     * Creates and delivers a simple notification.
     */
    public static void sendNotification(Context context, NotificationManager mNotifyManager, String topic, String title) {
        // Sets up the pending intent to update the notification.
        // Corresponds to a press of the Update Me! button.
        Intent updateIntent = new Intent(Strings.ACTION_UPDATE_NOTIFICATION);
        PendingIntent updatePendingIntent = PendingIntent.getBroadcast(context, Strings.NOTIFICATION_ID, updateIntent, PendingIntent.FLAG_ONE_SHOT);

        // Build the notification with all of the parameters using helper
        // method.
        NotificationCompat.Builder notifyBuilder = getNotificationBuilder(context, topic, title);

        // Add the action button using the pending intent.
       // notifyBuilder.addAction(android.R.drawable.star_on,context.getString(R.string.update), updatePendingIntent);

        // Deliver the notification.
        mNotifyManager.notify(generateRandom(), notifyBuilder.build());

    }

    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager)activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
    }

    public static void storeStringToSharedPreference(Context context, String key , String value){
        SharedPreferences sharedPreferences = context.getSharedPreferences(Strings.SHARED_PREFERENCE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        editor.commit();
    }

    public static String getStringSharedPreference(Context context, String key){
        SharedPreferences sharedPreferences = context.getSharedPreferences(Strings.SHARED_PREFERENCE, Context.MODE_PRIVATE);
        String value = sharedPreferences.getString(key, "");
        if(value==null || value.equals("null") || value.isEmpty()){
            value = "";
        }
        return value;
    }

    public static void endapp(Context context) {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.addCategory(Intent.CATEGORY_HOME);
        context.startActivity(intent);
        android.os.Process.killProcess(android.os.Process.myPid());
    }

    public static int generateRandom() {
        Random random = new Random();
        return random.nextInt(9999 - 1000) + 1000;
    }

    public static void deleteCache(Context context) {
        try {
            File dir = context.getCacheDir();
            deleteDir(dir);
        } catch (Exception e) { e.printStackTrace();}
    }

    public static boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
            return dir.delete();
        } else if(dir!= null && dir.isFile()) {
            return dir.delete();
        } else {
            return false;
        }
    }


    public static void generateTextView(final Context context, int textViewCount, LinearLayout linearLayout){

        final TextView[] myTextViews = new TextView[textViewCount]; // create an empty array;
        for (int i = 0; i < textViewCount; i++) {
            final TextView rowTextView = new TextView(context);
            rowTextView.setText("This is TextView #" + i);
            linearLayout.addView(rowTextView);
            myTextViews[i] = rowTextView;
            myTextViews[i].setClickable(true);
            myTextViews[i].setId(i);
            final int finalI = i;
            myTextViews[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(context, ""+myTextViews[finalI].getId(), Toast.LENGTH_SHORT).show();
                }
            });
        }

    }

}
