package com.sowmitras.mukul.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.sowmitras.mukul.R;
import com.sowmitras.mukul.utils.JSONData;
import com.sowmitras.mukul.utils.Methods;

import java.util.List;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.MyViewHolder> {

    private List<JSONData> moviesList;
    private Context context;


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView id, topic, title, message, url, time, idCount;
        public LinearLayout textviewLL;
        public ListView optionLink;

        public MyViewHolder(View view) {
            super(view);
            title = (TextView) view.findViewById(R.id.title);
            idCount = (TextView) view.findViewById(R.id.idCount);
            time = (TextView) view.findViewById(R.id.time);
            id = (TextView) view.findViewById(R.id.id);
            topic = (TextView) view.findViewById(R.id.topic);
            message = (TextView) view.findViewById(R.id.message);
            url = (TextView) view.findViewById(R.id.url);
            textviewLL = (LinearLayout) view.findViewById(R.id.textviewLL);
            optionLink = (ListView) view.findViewById(R.id.optionLink);
        }
    }


    public DataAdapter(List<JSONData> moviesList, Context context) {
        this.moviesList = moviesList;
       this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        JSONData movie = moviesList.get(position);
        holder.idCount.setText(Methods.spannedText(movie.getIdCount()));
        holder.title.setText(Methods.spannedText(movie.getTitle()));
        holder.time.setText(Methods.spannedText(movie.getTime()));
        holder.id.setText(Methods.spannedText(movie.getId()));
        holder.topic.setText(Methods.spannedText(movie.getTopic()));
        holder.message.setText(Methods.spannedText(movie.getMessage()));
        holder.url.setText(Methods.spannedText(movie.getUrl()));
    }

    @Override
    public int getItemCount() {
        return moviesList.size();
    }
}