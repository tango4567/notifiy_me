package com.sowmitras.mukul.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Table Name
    public static final String TABLE_NAME = "notification";

    // Table columns
    public static final String ID = "id";
    public static final String MAIN_ID = "_id";
    public static final String TIME = "time";

    public static final String TOPIC = "topic";
    public static final String TITLE = "title";
    public static final String MESSAGE = "message";
    public static final String URL = "url";
    public static final String LINK_COUNT = "link_count";
    public static final String ANCHOR_COUNT = "anchor_count";

    public static final String LINKS = "links";
    public static final String ANCHORS = "anchors";

    // Database Information
    static final String DB_NAME = "Mukul.DB";

    // database version
    static final int DB_VERSION = 1;

    // Creating table query
    private static final String CREATE_TABLE = "create table " + TABLE_NAME +
            "(" + MAIN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + ID +" TEXT NOT NULL UNIQUE,"
                + TIME +" TEXT,"
                + TITLE +" TEXT,"
                + TOPIC + " TEXT,"
                + MESSAGE + " TEXT,"
                + LINK_COUNT + " TEXT,"
                + ANCHOR_COUNT + " TEXT,"
                + ANCHORS + " TEXT,"
                + LINKS + " TEXT,"
                + URL + " TEXT);";

    /*CREATE TABLE COMPANY(
   ID   INT       PRIMARY KEY        NOT NULL,
   NAME          TEXT     NOT NULL,
   AGE  INT              NOT NULL UNIQUE,
   ADDRESS  CHAR (25) ,
   SALARY   REAL  ,

);*/


    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }


}
